import subprocess

def startMultipleInstances(executables):
    for exec in executables:
        cmd = f'start cmd /k python {exec}'
        print(f"Iniciando: {cmd}")
        subprocess.Popen(cmd, shell=True)

executable_to_run = [
    "principal.py",
    "estoque.py",
    #"payment.py",
    "delivery.py",
    "notifications.py"
]

startMultipleInstances(executable_to_run)